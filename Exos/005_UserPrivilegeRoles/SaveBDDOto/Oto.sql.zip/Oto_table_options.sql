
-- --------------------------------------------------------

--
-- Structure de la table `options`
--

CREATE TABLE `options` (
  `id_options` int(11) NOT NULL,
  `type_options` char(50) NOT NULL,
  `price_options` decimal(10,2) NOT NULL,
  `date_options` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `options`
--

INSERT INTO `options` (`id_options`, `type_options`, `price_options`, `date_options`) VALUES
(1, 'POSE GYROPHARE', '230.50', '2008-12-10 12:12:23'),
(2, 'FREINS', '150.20', '2018-11-10 14:16:52');
