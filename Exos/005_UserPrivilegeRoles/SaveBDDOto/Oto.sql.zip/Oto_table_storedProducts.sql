
-- --------------------------------------------------------

--
-- Structure de la table `storedProducts`
--

CREATE TABLE `storedProducts` (
  `id_products` int(11) NOT NULL,
  `name_storedProducts` char(50) NOT NULL,
  `price_storedProducts` decimal(6,2) NOT NULL,
  `stock_storedProducts` int(11) DEFAULT NULL,
  `id_technician` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `storedProducts`
--

INSERT INTO `storedProducts` (`id_products`, `name_storedProducts`, `price_storedProducts`, `stock_storedProducts`, `id_technician`) VALUES
(1, 'sapin déodorant', '3.99', 3, 0),
(2, 'clip a lunettes', '5.47', 0, 1),
(3, 'porte gobelet 5G', '3.23', 10, 2),
(4, 'autoradio', '200.00', 5, 1),
(5, 'ethylotest', '1.00', 230, 3),
(6, 'liquide de frein marque HBg', '66.66', 17, 2);
