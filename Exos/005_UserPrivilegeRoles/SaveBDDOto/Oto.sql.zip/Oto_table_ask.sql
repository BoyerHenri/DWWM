
-- --------------------------------------------------------

--
-- Structure de la table `ask`
--

CREATE TABLE `ask` (
  `id_client` int(11) NOT NULL,
  `id_commercial` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
