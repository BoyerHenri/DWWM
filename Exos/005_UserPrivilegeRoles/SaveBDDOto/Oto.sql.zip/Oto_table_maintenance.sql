
-- --------------------------------------------------------

--
-- Structure de la table `maintenance`
--

CREATE TABLE `maintenance` (
  `id_maintenance` int(11) NOT NULL,
  `id_technician` int(11) NOT NULL,
  `type_maintenance` char(10) NOT NULL,
  `price_maintenance` decimal(6,2) NOT NULL,
  `date_maintenance` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `maintenance`
--

INSERT INTO `maintenance` (`id_maintenance`, `id_technician`, `type_maintenance`, `price_maintenance`, `date_maintenance`) VALUES
(1, 1, 'ATELIER', '200.00', '2008-12-10 12:12:23');
