
-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL,
  `request_client` char(25) NOT NULL,
  `name_client` char(25) NOT NULL,
  `lastName_client` char(25) NOT NULL,
  `mail_client` char(40) DEFAULT NULL,
  `phoneNumber_client` varchar(20) DEFAULT NULL,
  `status_client` char(10) NOT NULL,
  `adress_client` char(50) NOT NULL,
  `zipCode_client` varchar(10) NOT NULL,
  `city_client` varchar(20) NOT NULL,
  `country_client` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_client`, `request_client`, `name_client`, `lastName_client`, `mail_client`, `phoneNumber_client`, `status_client`, `adress_client`, `zipCode_client`, `city_client`, `country_client`) VALUES
(1, 'achat vehicule', 'ARTHUR', 'Roi', '', '0612324520', 'PART', '3, Rue Bis', '80000', 'Kaamelot', 'Angleterre'),
(2, 'options', 'KARADOC', 'Lucien', '', '0722429570', 'PRO', '30, Avenue des pendus', '75000', 'St Just', 'France'),
(3, 'accessoires', 'JOSETTE', 'Lucienne', 'luciennejo@caramail.com', '0612142336', 'PART', '7, chemin des dahus', '06200', 'Vesubie', 'France'),
(4, 'reparations', 'TONY', 'Montana', '', '099555927', 'PRO', '112,Via Cabra', '32178', 'Roma', 'Italy'),
(5, 'pose', 'VICTOR', 'Nettoyeur', 'servicessecrets@gouf.fr', '0615231436', 'PART', '50, Avenue des palmiers', '62000', 'St Omer', 'France'),
(6, 'entretien', 'HECTOR', 'Humungus', '', '0482181666', 'PRO', '3 ZI les montieres', '13600', 'Marseille', 'France');
