
-- --------------------------------------------------------

--
-- Structure de la table `need`
--

CREATE TABLE `need` (
  `id_maintenance` int(11) NOT NULL,
  `id_repair` int(11) NOT NULL,
  `id_products` int(11) NOT NULL,
  `id_options` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
