
-- --------------------------------------------------------

--
-- Structure de la table `checks`
--

CREATE TABLE `checks` (
  `id_buy` int(11) NOT NULL,
  `id_storageVehicles` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
