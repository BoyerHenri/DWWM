
-- --------------------------------------------------------

--
-- Structure de la table `repair`
--

CREATE TABLE `repair` (
  `id_repair` int(11) NOT NULL,
  `type_repair` char(120) NOT NULL,
  `price_repair` decimal(6,2) NOT NULL,
  `date_repair` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `repair`
--

INSERT INTO `repair` (`id_repair`, `type_repair`, `price_repair`, `date_repair`) VALUES
(1, 'CONFORMITE', '0.00', '2008-12-10 12:12:23');
