
-- --------------------------------------------------------

--
-- Structure de la table `commercial`
--

CREATE TABLE `commercial` (
  `id_commercial` int(11) NOT NULL,
  `spe_commercial` char(10) NOT NULL,
  `name_commercial` char(25) NOT NULL,
  `lastName_commercial` char(25) NOT NULL,
  `mail_commercial` char(40) NOT NULL,
  `phone_commercial` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commercial`
--

INSERT INTO `commercial` (`id_commercial`, `spe_commercial`, `name_commercial`, `lastName_commercial`, `mail_commercial`, `phone_commercial`) VALUES
(1, 'PART', 'CONVENANT', 'Jean-Claude', 'JC@oto.fr', '0301052485'),
(2, 'PRO', 'N GOBO', 'Lucienne', 'ngobo@oto.fr', '0204052389');
