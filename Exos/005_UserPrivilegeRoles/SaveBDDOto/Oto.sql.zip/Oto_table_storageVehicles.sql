
-- --------------------------------------------------------

--
-- Structure de la table `storageVehicles`
--

CREATE TABLE `storageVehicles` (
  `id_storageVehicles` int(11) NOT NULL,
  `name_storageVehicles` char(50) NOT NULL,
  `brand_storageVehicles` varchar(50) DEFAULT NULL,
  `stock_storageVehicles` int(11) DEFAULT NULL,
  `price_storageVehicles` decimal(15,2) NOT NULL,
  `age_storageVehicles` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `storageVehicles`
--

INSERT INTO `storageVehicles` (`id_storageVehicles`, `name_storageVehicles`, `brand_storageVehicles`, `stock_storageVehicles`, `price_storageVehicles`, `age_storageVehicles`) VALUES
(1, 'Megane', 'Renault', 3, '8090.00', 0),
(2, 'Panda', 'Fiat', 2, '15000.00', 2003),
(3, '306', 'Peugeot', 5, '7000.00', 1995),
(4, 'Mad Cat', 'Inner Sphere', 1, '300000.00', 0);
