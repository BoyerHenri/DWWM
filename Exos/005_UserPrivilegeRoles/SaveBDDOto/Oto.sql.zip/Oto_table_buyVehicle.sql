
-- --------------------------------------------------------

--
-- Structure de la table `buyVehicle`
--

CREATE TABLE `buyVehicle` (
  `id_buy` int(11) NOT NULL,
  `buy_date` datetime NOT NULL,
  `buy_funding` char(10) NOT NULL,
  `id_storageVehicles` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `buyVehicle`
--

INSERT INTO `buyVehicle` (`id_buy`, `buy_date`, `buy_funding`, `id_storageVehicles`) VALUES
(1, '2008-12-10 12:12:23', 'CRED', 1),
(2, '2012-05-03 15:26:12', 'COMPT', 2),
(3, '2021-05-12 17:12:58', 'COMPT', 3),
(4, '1932-03-01 16:23:22', 'COMPT', 4),
(5, '2000-11-01 14:52:32', 'CRED', 5);
