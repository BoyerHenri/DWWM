
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `ask`
--
ALTER TABLE `ask`
  ADD PRIMARY KEY (`id_client`,`id_commercial`),
  ADD KEY `id_commercial` (`id_commercial`);

--
-- Index pour la table `buyVehicle`
--
ALTER TABLE `buyVehicle`
  ADD PRIMARY KEY (`id_buy`);

--
-- Index pour la table `checks`
--
ALTER TABLE `checks`
  ADD PRIMARY KEY (`id_buy`,`id_storageVehicles`),
  ADD KEY `id_storageVehicles` (`id_storageVehicles`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id_client`);

--
-- Index pour la table `commercial`
--
ALTER TABLE `commercial`
  ADD PRIMARY KEY (`id_commercial`);

--
-- Index pour la table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`id_maintenance`);

--
-- Index pour la table `need`
--
ALTER TABLE `need`
  ADD PRIMARY KEY (`id_maintenance`,`id_repair`,`id_products`,`id_options`),
  ADD KEY `id_repair` (`id_repair`),
  ADD KEY `id_products` (`id_products`),
  ADD KEY `id_options` (`id_options`);

--
-- Index pour la table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id_options`);

--
-- Index pour la table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`id_repair`);

--
-- Index pour la table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id_commercial`,`id_buy`,`id_maintenance`,`id_repair`),
  ADD KEY `id_buy` (`id_buy`),
  ADD KEY `id_maintenance` (`id_maintenance`),
  ADD KEY `id_repair` (`id_repair`);

--
-- Index pour la table `storageVehicles`
--
ALTER TABLE `storageVehicles`
  ADD PRIMARY KEY (`id_storageVehicles`);

--
-- Index pour la table `storedProducts`
--
ALTER TABLE `storedProducts`
  ADD PRIMARY KEY (`id_products`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `buyVehicle`
--
ALTER TABLE `buyVehicle`
  MODIFY `id_buy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `commercial`
--
ALTER TABLE `commercial`
  MODIFY `id_commercial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `id_maintenance` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `options`
--
ALTER TABLE `options`
  MODIFY `id_options` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `repair`
--
ALTER TABLE `repair`
  MODIFY `id_repair` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `storageVehicles`
--
ALTER TABLE `storageVehicles`
  MODIFY `id_storageVehicles` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `storedProducts`
--
ALTER TABLE `storedProducts`
  MODIFY `id_products` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `ask`
--
ALTER TABLE `ask`
  ADD CONSTRAINT `ask_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`),
  ADD CONSTRAINT `ask_ibfk_2` FOREIGN KEY (`id_commercial`) REFERENCES `commercial` (`id_commercial`);

--
-- Contraintes pour la table `checks`
--
ALTER TABLE `checks`
  ADD CONSTRAINT `checks_ibfk_1` FOREIGN KEY (`id_buy`) REFERENCES `buyVehicle` (`id_buy`),
  ADD CONSTRAINT `checks_ibfk_2` FOREIGN KEY (`id_storageVehicles`) REFERENCES `storageVehicles` (`id_storageVehicles`);

--
-- Contraintes pour la table `need`
--
ALTER TABLE `need`
  ADD CONSTRAINT `need_ibfk_1` FOREIGN KEY (`id_maintenance`) REFERENCES `maintenance` (`id_maintenance`),
  ADD CONSTRAINT `need_ibfk_2` FOREIGN KEY (`id_repair`) REFERENCES `repair` (`id_repair`),
  ADD CONSTRAINT `need_ibfk_3` FOREIGN KEY (`id_products`) REFERENCES `storedProducts` (`id_products`),
  ADD CONSTRAINT `need_ibfk_4` FOREIGN KEY (`id_options`) REFERENCES `options` (`id_options`);

--
-- Contraintes pour la table `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `request_ibfk_1` FOREIGN KEY (`id_commercial`) REFERENCES `commercial` (`id_commercial`),
  ADD CONSTRAINT `request_ibfk_2` FOREIGN KEY (`id_buy`) REFERENCES `buyVehicle` (`id_buy`),
  ADD CONSTRAINT `request_ibfk_3` FOREIGN KEY (`id_maintenance`) REFERENCES `maintenance` (`id_maintenance`),
  ADD CONSTRAINT `request_ibfk_4` FOREIGN KEY (`id_repair`) REFERENCES `repair` (`id_repair`);
