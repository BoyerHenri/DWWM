
-- --------------------------------------------------------

--
-- Structure de la table `request`
--

CREATE TABLE `request` (
  `id_commercial` int(11) NOT NULL,
  `id_buy` int(11) NOT NULL,
  `id_maintenance` int(11) NOT NULL,
  `id_repair` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `finalQuote_price_HT` decimal(15,2) NOT NULL,
  `finalQuote_price_TTC` decimal(15,2) NOT NULL,
  `VAT_value` decimal(4,2) NOT NULL,
  `quote_date` datetime NOT NULL,
  `quote_accept` smallint(6) DEFAULT NULL,
  `quote_paid` smallint(6) DEFAULT NULL,
  `quote_paidDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `request`
--

INSERT INTO `request` (`id_commercial`, `id_buy`, `id_maintenance`, `id_repair`, `id_client`, `finalQuote_price_HT`, `finalQuote_price_TTC`, `VAT_value`, `quote_date`, `quote_accept`, `quote_paid`, `quote_paidDate`) VALUES
(1, 1, 1, 1, 5, '15000.00', '15206.00', '20.60', '2008-12-10 12:12:23', 1, 1, '2008-12-10 12:12:23');
